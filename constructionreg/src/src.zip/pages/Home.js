import React from 'react';
import  Carousel from  '../pages/Carosuel';



const Home = () => {
  return (
    <div>
  
    </div>
  );
};
export default Home;
