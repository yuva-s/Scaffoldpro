import React from 'react';



const  Services=() =>{
return(

<h1>Services pages</h1>
  
)
}
export default  Services;