import React from 'react';



const  About=() =>{
return(

   <h1>About pages</h1>
  
)
}
export default About;