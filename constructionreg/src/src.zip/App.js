import React from 'react';
import './App.css';
import {BrowserRouter as Router, Switch, Route, Link} from 'react-router-dom';
import Register from './pages/Register';
import Login from './pages/Login';
import Home  from './pages/Home';
import About from './pages/About';
import  Services     from './pages/Services';
import Contact from './pages/Contact';
import Policy from './pages/Policy';
import List from './Reuse/List';
import Carousel from './pages/Carosuel'
import Footer from './Reuse/Footer'
import Cards from './pages/Cards'



function App() {
  return(
    <Router>
      <List/>
      <Carousel/>
      <div style={{display:"flex", flexWrap:"wrap",gap:"50px",padding:"100px"}}>
      {
        Array(20).fill("jksfhjkk").map(e=>{
          return(
            <Cards/>
          )
        })
      }
      </div>
      <Footer/>
      <Switch>
     
        <Route path='/Register'>
          <Register/>
         </Route>

         <Route path='/Login'>
          <Login/>
         </Route>
         
         <Route exact path="/" pages={Home}>
           <Home/>
         </Route>

         <Route  path="/about" pages={About}>
           <About/>
         </Route>


         <Route  path="/services" pages={Services}>
           <Services/>
         </Route>


         <Route  path="/contact" pages={Contact}>
           <Contact/>
         </Route>

         <Route  path="/policy" pages={Policy}>
           <Policy/>
         </Route>


      

      </Switch>
    </Router>
  )
};
export default App;