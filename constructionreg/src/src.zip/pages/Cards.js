import { Card } from 'antd';


const { Meta } = Card;
const Cards = () => (
  <Card
    hoverable
    style={{
      width: 240,
    pafddingbottom:"20px",
    }}

    cover={
      <img
        alt="example"
        src="https://os.alipayobjects.com/rmsportal/QBnOOoLaAfKPirc.png"
        style={{ height: '150px' }} // Adjust the height here
      />
    }
  >
    <Meta title="Europe Street beat" description="www.instagram.com" />
  </Card>
);
export default Cards;