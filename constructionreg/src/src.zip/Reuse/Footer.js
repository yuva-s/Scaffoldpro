import {  Footer } from 'antd/es/layout/layout';

function footer (){
    return <Footer><h1>Scafold</h1></Footer>
};
export default footer;