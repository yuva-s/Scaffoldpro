import React from 'react';



const  Policy=() =>{
return(

<h1>policy pages</h1>
  
)
}
export default  Policy;